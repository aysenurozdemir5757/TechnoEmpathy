# OpenAPI `models`

OpenAPI Pydantic models used to generate and validate the generated OpenAPI.

::: fastapi.openapi.models
