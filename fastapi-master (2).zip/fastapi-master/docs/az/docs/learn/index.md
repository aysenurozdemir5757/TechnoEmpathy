# Öyrən

Burada **FastAPI** öyrənmək üçün giriş bölmələri və dərsliklər yer alır.

Siz bunu kitab, kurs, FastAPI öyrənmək üçün rəsmi və tövsiyə olunan üsul hesab edə bilərsiniz. 😎
