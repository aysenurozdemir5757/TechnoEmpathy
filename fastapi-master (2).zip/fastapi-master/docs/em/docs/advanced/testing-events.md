# 🔬 🎉: 🕴 - 🤫

🕐❔ 👆 💪 👆 🎉 🐕‍🦺 (`startup` &amp; `shutdown`) 🏃 👆 💯, 👆 💪 ⚙️ `TestClient` ⏮️ `with` 📄:

{* ../../docs_src/app_testing/tutorial003.py hl[9:12,20:24] *}
