# 🏧 🔗

## 🔗 🔗

🌐 🔗 👥 ✔️ 👀 🔧 🔢 ⚖️ 🎓.

✋️ 📤 💪 💼 🌐❔ 👆 💚 💪 ⚒ 🔢 🔛 🔗, 🍵 ✔️ 📣 📚 🎏 🔢 ⚖️ 🎓.

➡️ 🌈 👈 👥 💚 ✔️ 🔗 👈 ✅ 🚥 🔢 🔢 `q` 🔌 🔧 🎚.

✋️ 👥 💚 💪 🔗 👈 🔧 🎚.

##  "🇧🇲" 👐

🐍 📤 🌌 ⚒ 👐 🎓 "🇧🇲".

🚫 🎓 ⚫️ (❔ ⏪ 🇧🇲), ✋️ 👐 👈 🎓.

👈, 👥 📣 👩‍🔬 `__call__`:

{* ../../docs_src/dependencies/tutorial011.py hl[10] *}

👉 💼, 👉 `__call__` ⚫️❔ **FastAPI** 🔜 ⚙️ ✅ 🌖 🔢 &amp; 🎧-🔗, &amp; 👉 ⚫️❔ 🔜 🤙 🚶‍♀️ 💲 🔢 👆 *➡ 🛠️ 🔢* ⏪.

## 🔗 👐

&amp; 🔜, 👥 💪 ⚙️ `__init__` 📣 🔢 👐 👈 👥 💪 ⚙️ "🔗" 🔗:

{* ../../docs_src/dependencies/tutorial011.py hl[7] *}

👉 💼, **FastAPI** 🏆 🚫 ⏱ 👆 ⚖️ 💅 🔃 `__init__`, 👥 🔜 ⚙️ ⚫️ 🔗 👆 📟.

## ✍ 👐

👥 💪 ✍ 👐 👉 🎓 ⏮️:

{* ../../docs_src/dependencies/tutorial011.py hl[16] *}

&amp; 👈 🌌 👥 💪 "🔗" 👆 🔗, 👈 🔜 ✔️ `"bar"` 🔘 ⚫️, 🔢 `checker.fixed_content`.

## ⚙️ 👐 🔗

⤴️, 👥 💪 ⚙️ 👉 `checker` `Depends(checker)`, ↩️ `Depends(FixedContentQueryChecker)`, ↩️ 🔗 👐, `checker`, 🚫 🎓 ⚫️.

&amp; 🕐❔ ❎ 🔗, **FastAPI** 🔜 🤙 👉 `checker` 💖:

```Python
checker(q="somequery")
```

...&amp; 🚶‍♀️ ⚫️❔ 👈 📨 💲 🔗 👆 *➡ 🛠️ 🔢* 🔢 `fixed_content_included`:

{* ../../docs_src/dependencies/tutorial011.py hl[20] *}

/// tip

🌐 👉 💪 😑 🎭. &amp; ⚫️ 💪 🚫 📶 🆑 ❔ ⚫️ ⚠.

👫 🖼 😫 🙅, ✋️ 🎦 ❔ ⚫️ 🌐 👷.

📃 🔃 💂‍♂, 📤 🚙 🔢 👈 🛠️ 👉 🎏 🌌.

🚥 👆 🤔 🌐 👉, 👆 ⏪ 💭 ❔ 👈 🚙 🧰 💂‍♂ 👷 🔘.

///
