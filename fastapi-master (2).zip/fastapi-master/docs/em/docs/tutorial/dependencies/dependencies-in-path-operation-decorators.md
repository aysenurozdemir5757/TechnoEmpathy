# 🔗 ➡ 🛠️ 👨‍🎨

💼 👆 🚫 🤙 💪 📨 💲 🔗 🔘 👆 *➡ 🛠️ 🔢*.

⚖️ 🔗 🚫 📨 💲.

✋️ 👆 💪 ⚫️ 🛠️/❎.

📚 💼, ↩️ 📣 *➡ 🛠️ 🔢* 🔢 ⏮️ `Depends`, 👆 💪 🚮 `list` `dependencies` *➡ 🛠️ 👨‍🎨*.

## 🚮 `dependencies` *➡ 🛠️ 👨‍🎨*

*➡ 🛠️ 👨‍🎨* 📨 📦 ❌ `dependencies`.

⚫️ 🔜 `list` `Depends()`:

{* ../../docs_src/dependencies/tutorial006.py hl[17] *}

👉 🔗 🔜 🛠️/❎ 🎏 🌌 😐 🔗. ✋️ 👫 💲 (🚥 👫 📨 🙆) 🏆 🚫 🚶‍♀️ 👆 *➡ 🛠️ 🔢*.

/// tip

👨‍🎨 ✅ ♻ 🔢 🔢, &amp; 🎦 👫 ❌.

⚙️ 👉 `dependencies` *➡ 🛠️ 👨‍🎨* 👆 💪 ⚒ 💭 👫 🛠️ ⏪ ❎ 👨‍🎨/🏭 ❌.

⚫️ 💪 ℹ ❎ 😨 🆕 👩‍💻 👈 👀 ♻ 🔢 👆 📟 &amp; 💪 💭 ⚫️ 🙃.

///

/// info

👉 🖼 👥 ⚙️ 💭 🛃 🎚 `X-Key` &amp; `X-Token`.

✋️ 🎰 💼, 🕐❔ 🛠️ 💂‍♂, 👆 🔜 🤚 🌖 💰 ⚪️➡️ ⚙️ 🛠️ [💂‍♂ 🚙 (⏭ 📃)](../security/index.md){.internal-link target=_blank}.

///

## 🔗 ❌ &amp; 📨 💲

👆 💪 ⚙️ 🎏 🔗 *🔢* 👆 ⚙️ 🛎.

### 🔗 📄

👫 💪 📣 📨 📄 (💖 🎚) ⚖️ 🎏 🎧-🔗:

{* ../../docs_src/dependencies/tutorial006.py hl[6,11] *}

### 🤚 ⚠

👫 🔗 💪 `raise` ⚠, 🎏 😐 🔗:

{* ../../docs_src/dependencies/tutorial006.py hl[8,13] *}

### 📨 💲

&amp; 👫 💪 📨 💲 ⚖️ 🚫, 💲 🏆 🚫 ⚙️.

, 👆 💪 🏤-⚙️ 😐 🔗 (👈 📨 💲) 👆 ⏪ ⚙️ 👱 🙆, &amp; ✋️ 💲 🏆 🚫 ⚙️, 🔗 🔜 🛠️:

{* ../../docs_src/dependencies/tutorial006.py hl[9,14] *}

## 🔗 👪 *➡ 🛠️*

⏪, 🕐❔ 👂 🔃 ❔ 📊 🦏 🈸 ([🦏 🈸 - 💗 📁](../../tutorial/bigger-applications.md){.internal-link target=_blank}), 🎲 ⏮️ 💗 📁, 👆 🔜 💡 ❔ 📣 👁 `dependencies` 🔢 👪 *➡ 🛠️*.

## 🌐 🔗

⏭ 👥 🔜 👀 ❔ 🚮 🔗 🎂 `FastAPI` 🈸, 👈 👫 ✔ 🔠 *➡ 🛠️*.
